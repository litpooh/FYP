//
//  Rate.swift
//  DatabaseFetch
//
//  Created by hi on 12/3/2022.
//

import Foundation

struct Rate {
    var cp_id: Int = 0
    var email: String = ""
    var score: Int = 0
    var dirty: Int = 0
    var full: Int = 0
    var transportation: Int = 0
    var wrong: Int = 0
    var impolite: Int = 0
}
