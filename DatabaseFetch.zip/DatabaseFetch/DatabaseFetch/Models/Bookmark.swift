//
//  Bookmark.swift
//  DatabaseFetch
//
//  Created by hi on 2/4/2022.
//

import Foundation
struct Bookmark {
    var cp_id: Int = 0
    var email: String = ""
}
